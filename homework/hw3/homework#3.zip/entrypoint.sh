#!/bin/bash

set -e
exec zsh
exec "$@"